/*
 * BQ25883_Controller.h
 *
 *  Created on: Jun 18, 2023
 *      Author: PC
 */

#ifndef SRC_BQ25883_CONTROLLER_H_
#define SRC_BQ25883_CONTROLLER_H_

#ifdef ENABLE_BQ25883

void BQ25883_Init_Controller();

#endif /* ENABLE_BQ25883 */

#endif /* SRC_BQ25883_CONTROLLER_H_ */
